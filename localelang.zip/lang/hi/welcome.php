<?php

return [
    "hello" => "नमस्ते",
    "this" => "यह",
    "is" => "है",
    "my" => "मेरा",
    "first" => "पहला",
    "localization" => "स्थानीयकरण।",
    "thank_you" => "धन्यवाद!",
];