<?php

return [
    "hello" => "Hello",
    "this"=> "this",
    "is"=> "is",
    "my"=> "my",
    "first" => "first.",
    "localization" => "localization.",
    "thank_you" => "Thank you!"
];