<?php
return [
    "hello" => "你好",
    "this" => "这",
    "is" => "是",
    "my" => "我的",
    "first" => "第一个",
    "localization" => "本地化。",
    "thank_you" => "谢谢！",
];
