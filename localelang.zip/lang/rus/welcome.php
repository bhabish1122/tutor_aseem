<?php

return [
    "hello" => "Здравствуйте",
    "this" => "Это",
    "is" => "есть",
    "my" => "Мой",
    "first" => "первый",
    "localization" => "локализация.",
    "thank_you" => "Спасибо!",
];