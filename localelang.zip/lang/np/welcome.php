<?php

return [
    "hello" => "नमस्ते",
    "this" => "यो",
    "is" => "हो",
    "my" => "मेरो",
    "first" => "पहिलो",
    "localization" => "स्थानीयकरण।",
    "thank_you" => "धन्यवाद!",
];