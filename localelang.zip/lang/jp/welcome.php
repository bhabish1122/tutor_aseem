<?php

return [
    "hello" => "こんにちは",
    "this" => "これ",
    "is" => "は",
    "my" => "私の",
    "first" => "最初の",
    "localization" => "ローカリゼーション。",
    "thank_you" => "ありがとうございます！",
];
