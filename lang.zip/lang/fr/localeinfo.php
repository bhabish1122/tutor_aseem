<?php

return [
    "hello" => "Bonjour",
    "world" => "monde",
];