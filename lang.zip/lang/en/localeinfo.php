<?php

return [
    "hello" => "Hello",
    "world" => "Worlds"
];