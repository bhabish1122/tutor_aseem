<?php

return [
    "hello" => "नमस्ते",
    "world" => "संसार",
];